package _sb0322.service;

public class WrongIdPasswordException extends RuntimeException {

}
