package _sb0322_01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sb03221ApplicationTests {

	@Test
	void contextLoads() {
	}

}
