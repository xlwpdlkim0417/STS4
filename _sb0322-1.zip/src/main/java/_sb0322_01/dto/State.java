package _sb0322_01.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class State {

	private int deptno;
	private int empno;
}
